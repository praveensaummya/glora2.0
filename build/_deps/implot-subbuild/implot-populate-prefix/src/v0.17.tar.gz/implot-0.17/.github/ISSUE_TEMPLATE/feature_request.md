---
name: 🚀 Feature request
about: Suggest an idea or enhancement for ImPlot
title: '[Feature] A brief, descriptive title'
labels: type:feat, status:idea, prio:medium
---
**Feature description**
A clear and concise description of the new feature.

**Feature videos/screenshots**
Attach png/jpg/mp4/gif files if applicable to help explain your idea.
